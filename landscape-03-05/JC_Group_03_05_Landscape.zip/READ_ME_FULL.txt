JC Group — 完整横屏版 / FULL 16:9 presentations

本压缩包只有两套完整文件，每套 22 页。

1. 03_Editorial_Landscape.pptx — 第 3 套，完整可编辑 PPT，22 页
2. 03_Editorial_Landscape.pdf — 第 3 套，完整 PDF，22 页
3. 05_Signature_Landscape.pptx — 第 5 套，完整可编辑 PPT，22 页
4. 05_Signature_Landscape.pdf — 第 5 套，完整 PDF，22 页

资料顺序：集团概况、愿景使命、JC Marine Integration、设备服务、地区服务范围、品牌代理、维护检测、罗经服务、JC Connexion、卫星资费、VSAT/Starlink、设备租赁、流量控制、船舶追踪、IT 网络、JC Supply、船舶供应、校准与制作、火警系统、技术文档、联络方式。

此前 8 页的重点预览不是完整版，未放入本压缩包。
